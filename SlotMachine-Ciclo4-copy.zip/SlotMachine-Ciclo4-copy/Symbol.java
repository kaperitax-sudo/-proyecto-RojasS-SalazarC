import java.util.ArrayList;

/**
 * Un simbolo normal de la maquina. Se identifica por su color
 * y se dibuja como un cuadrado solido.
 * Es la base de los demas tipos de simbolo (ephemeral, shy, wild).
 * Las subclases no deben inicializar atributos en su declaracion,
 * porque el constructor de Symbol llama a build() antes que ellas.
 * Para crear un simbolo de cualquier tipo se usa {@link #create(String, String)}.
 */
public class Symbol
{
    public static final int SIZE = 22;              // tamaño del simbolo

    /** Tipos de simbolo que conoce el simulador. */
    public static final String[] TYPES = {"normal", "ephemeral", "shy", "wild"};

    protected String color;
    protected ArrayList<Rectangle> parts;           // sus pedacitos
    protected int xPosition;                        // esquina del espacio SIZE x SIZE
    protected int yPosition;
    protected boolean isVisible;

    /**
     * Crea un simbolo normal invisible del color dado.
     * @param color nombre de un color CSS
     */
    public Symbol(String color)
    {
        this.color = color;
        parts = new ArrayList<Rectangle>();
        xPosition = 0;
        yPosition = 0;
        isVisible = false;
        build();                                     // cada tipo arma sus pedacitos
    }

    /**
     * Crea un simbolo del tipo dado.
     * @param type tipo del simbolo: normal, ephemeral, shy o wild
     * @param color nombre de un color CSS
     * @return el simbolo, o null si el tipo no existe
     */
    public static Symbol create(String type, String color)
    {
        String value = (type == null) ? "" : type.toLowerCase();
        switch (value) {
            case "normal":    return new Symbol(color);
            case "ephemeral": return new EphemeralSymbol(color);
            case "shy":       return new ShySymbol(color);
            case "wild":      return new WildSymbol(color);
            default:          return null;
        }
    }

    /**
     * Indica si existe un tipo de simbolo con ese nombre.
     * @param type nombre del tipo
     * @return true si el simulador lo conoce
     */
    public static boolean isType(String type)
    {
        if (type == null) {
            return false;
        }
        for (String known : TYPES) {
            if (known.equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Indica el tipo del simbolo.
     * @return nombre del tipo
     */
    public String type()
    {
        return "normal";
    }

    /**
     * Indica el color del simbolo.
     * @return nombre del color
     */
    public String color()
    {
        return color;
    }

    /**
     * Indica si el simbolo es de ese color.
     * @param other nombre de color
     * @return true si es el mismo
     */
    public boolean is(String other)
    {
        return other != null && color.equalsIgnoreCase(other);
    }

    /**
     * Indica el tamaño con el que se dibuja el simbolo.
     * @return lado del cuadrado en pixeles
     */
    public int size()
    {
        return SIZE;
    }

    /**
     * Indica si el simbolo se deja ver cuando su rueda lo muestra.
     * @return true si se dibuja
     */
    public boolean isShown()
    {
        return true;
    }

    /**
     * Indica si el simbolo es comodin: sirve como cualquier otro para el premio.
     * @return true si es comodin
     */
    public boolean isWild()
    {
        return false;
    }

    /**
     * Avisa al simbolo que su rueda giro.
     * El simbolo normal no cambia.
     */
    public void turned()
    {
    }

    /**
     * Avisa al simbolo que su rueda lo dejo como el simbolo visible.
     * El simbolo normal no cambia.
     */
    public void selected()
    {
    }

    /**
     * Ubica el simbolo en el canvas.
     * @param x coordenada horizontal de la esquina del espacio del simbolo
     * @param y coordenada vertical de la esquina del espacio del simbolo
     */
    public void moveTo(int x, int y)
    {
        xPosition = x;
        yPosition = y;
        arrange();
    }

    /**
     * Hace visible el simbolo.
     */
    public void makeVisible()
    {
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible el simbolo.
     */
    public void makeInvisible()
    {
        for (Rectangle part : parts) {
            part.makeInvisible();
        }
        isVisible = false;
    }

    /**
     * Arma los pedacitos de la figura. El normal es un cuadrado solido.
     */
    protected void build()
    {
        parts.add(square(color));
    }

    /**
     * Ubica y dimensiona los pedacitos segun el estado del simbolo.
     */
    protected void arrange()
    {
        place(parts.get(0), 0, 0, SIZE, SIZE);
    }

    /**
     * Dibuja los pedacitos que se deben ver.
     */
    protected void draw()
    {
        for (Rectangle part : parts) {
            part.makeVisible();
        }
    }

    /**
     * Crea un pedacito cuadrado del color dado.
     * @param partColor color del pedacito
     * @return el pedacito, invisible
     */
    protected Rectangle square(String partColor)
    {
        Rectangle part = new Rectangle();
        part.changeColor(partColor);
        return part;
    }

    /**
     * Ubica un pedacito relativo a la esquina del simbolo.
     * @param part el pedacito
     * @param dx desplazamiento horizontal
     * @param dy desplazamiento vertical
     * @param width ancho
     * @param height alto
     */
    protected void place(Rectangle part, int dx, int dy, int width, int height)
    {
        part.changeSize(height, width);
        part.moveTo(xPosition + dx, yPosition + dy);
    }
}
