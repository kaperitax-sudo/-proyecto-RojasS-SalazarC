import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad del simulador, ciclo 4: tipos de ruedas y de simbolos.
 * Todas corren con la maquina invisible.
 * La maquina de prueba tiene tres simbolos normales (red, blue, green)
 * y tres ruedas normales, una en cada simbolo.
 */
public class SlotMachineC4Test
{
    private SlotMachine machine;

    /**
     * Arma la maquina de prueba, invisible y en una configuracion conocida.
     */
    @Before
    public void setUp()
    {
        machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.placeSymbol(3, "green");
    }

    // ---------- Requisito 16: tipos de ruedas y de simbolos ----------

    @Test
    public void shouldAddWheelsOfEveryType()
    {
        machine.addWheel("normal", 4);
        assertTrue(machine.ok());
        machine.addWheel("lefty", 5);
        assertTrue(machine.ok());
        machine.addWheel("REBEL", 6);
        assertTrue(machine.ok());
        assertEquals(6, machine.configuration().length);
    }

    @Test
    public void shouldNotAddAWheelOfAnUnknownType()
    {
        machine.addWheel("crazy", 1);
        assertFalse(machine.ok());
        machine.addWheel(null, 1);
        assertFalse(machine.ok());
        assertEquals(3, machine.configuration().length);
    }

    @Test
    public void shouldAddSymbolsOfEveryType()
    {
        machine.addSymbol("ephemeral", 4, "yellow");
        assertTrue(machine.ok());
        machine.addSymbol("shy", 5, "purple");
        assertTrue(machine.ok());
        machine.addSymbol("wild", 6, "orange");
        assertTrue(machine.ok());
        assertArrayEquals(new String[] {"red", "blue", "green", "yellow", "purple", "orange"},
                          machine.symbols());
    }

    @Test
    public void shouldNotAddASymbolOfAnUnknownType()
    {
        machine.addSymbol("magic", 1, "yellow");
        assertFalse(machine.ok());
        assertEquals(3, machine.symbols().length);
    }

    @Test
    public void shouldKeepTheTypeOfTheSymbolsInNewWheels()
    {
        machine.addSymbol("wild", 1, "orange");
        machine.addWheel("normal", 4);
        machine.spin(new String[] {"red", "red", "red", "orange"});
        assertTrue(machine.isJackpot());               // la nueva rueda tambien tiene el comodin
    }

    @Test
    public void shouldDeleteASymbolOfAnyType()
    {
        machine.addSymbol("shy", 4, "purple");
        machine.delSymbol("purple");
        assertTrue(machine.ok());
        assertArrayEquals(new String[] {"red", "blue", "green"}, machine.symbols());
    }

    // ---------- Requisito 17: lefty ----------

    @Test
    public void leftyShouldCopyTheLeftWheelWhenSpinning()
    {
        machine.addWheel("lefty", 2);                  // queda entre red y blue
        machine.spin(2);
        assertTrue(machine.ok());
        assertEquals("red", machine.configuration()[1]);
    }

    @Test
    public void leftyShouldCopyTheLeftWheelWhenRotating()
    {
        machine.addWheel("lefty", 4);
        machine.spin(4, 2);
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[3]);
    }

    @Test
    public void leftyShouldCopyTheNewStateOfTheLeftWheelWhenSpinningAll()
    {
        machine.addWheel("lefty", 2);
        machine.addWheel("lefty", 3);                  // dos zurdas seguidas
        for (int i = 0; i < 20; i++) {
            machine.spin();
            String[] config = machine.configuration();
            assertEquals(config[0], config[1]);
            assertEquals(config[1], config[2]);
        }
    }

    @Test
    public void leftyWithoutALeftWheelShouldRotateLikeANormalOne()
    {
        machine.addWheel("lefty", 1);                  // nace mostrando red
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
        machine.spin(1, -2);
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void leftyShouldNotSpinWhenLocked()
    {
        machine.addWheel("lefty", 2);
        machine.lock(2);
        assertTrue(machine.ok());
        machine.spin(2);
        assertFalse(machine.ok());
    }

    @Test
    public void leftyShouldBePlacedFreely()
    {
        machine.addWheel("lefty", 2);
        machine.placeSymbol(2, "green");               // colocar no es girar
        assertEquals("green", machine.configuration()[1]);
    }

    // ---------- Requisito 17: rebel ----------

    @Test
    public void rebelShouldNotBeLocked()
    {
        machine.addWheel("rebel", 4);
        machine.lock(4);
        assertFalse(machine.ok());
        machine.spin(4);
        assertTrue(machine.ok());                      // sigue girando
    }

    @Test
    public void rebelShouldNotBeSwapped()
    {
        machine.addWheel("rebel", 2);
        machine.placeSymbol(2, "green");
        machine.swap(1, 2);
        assertFalse(machine.ok());
        machine.swap(2, 4);
        assertFalse(machine.ok());
        assertArrayEquals(new String[] {"red", "green", "blue", "green"}, machine.configuration());
    }

    @Test
    public void rebelShouldNotBeDeleted()
    {
        machine.addWheel("rebel", 1);
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertEquals(4, machine.configuration().length);
        machine.delWheel(2);                           // las normales si se eliminan
        assertTrue(machine.ok());
        assertEquals(3, machine.configuration().length);
    }

    @Test
    public void rebelShouldLetTheOtherWheelsBeSwapped()
    {
        machine.addWheel("rebel", 2);
        machine.swap(1, 3);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    // ---------- Requisito 18: ephemeral ----------

    @Test
    public void ephemeralShouldShrinkInEachSpin()
    {
        Wheel wheel = wheelWith("ephemeral");
        Symbol red = wheel.getSymbol("red");
        assertEquals(Symbol.SIZE, red.size());
        wheel.rotate(1);
        assertEquals(Symbol.SIZE - EphemeralSymbol.STEP, red.size());
        wheel.spin(new java.util.Random());
        assertEquals(Symbol.SIZE - 2 * EphemeralSymbol.STEP, red.size());
    }

    @Test
    public void ephemeralShouldEndAsADot()
    {
        Wheel wheel = wheelWith("ephemeral");
        for (int i = 0; i < 50; i++) {
            wheel.rotate(1);
        }
        assertEquals(EphemeralSymbol.MIN_SIZE, wheel.getSymbol("red").size());
    }

    @Test
    public void ephemeralShouldNotShrinkWhenPlaced()
    {
        Wheel wheel = wheelWith("ephemeral");
        wheel.place("blue");
        assertEquals(Symbol.SIZE, wheel.getSymbol("red").size());
    }

    @Test
    public void ephemeralShouldKeepWorkingInTheMachine()
    {
        machine.addSymbol("ephemeral", 4, "yellow");
        for (int i = 0; i < 10; i++) {
            machine.spin(1, 1);
        }
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[0]);  // 10 pasos en 4 = 2
    }

    // ---------- Requisito 18: shy ----------

    @Test
    public void shyShouldToggleEachTimeItIsSelected()
    {
        Wheel wheel = wheelWith("shy");
        Symbol blue = wheel.getSymbol("blue");
        assertTrue(blue.isShown());
        wheel.place("blue");
        assertFalse(blue.isShown());
        wheel.rotate(3);                               // da la vuelta y vuelve a blue
        assertTrue(blue.isShown());
        wheel.place("blue");
        assertFalse(blue.isShown());
    }

    @Test
    public void shyShouldNotToggleWhenAnotherSymbolIsSelected()
    {
        Wheel wheel = wheelWith("shy");
        Symbol blue = wheel.getSymbol("blue");
        wheel.place("red");
        wheel.place("green");
        assertTrue(blue.isShown());
    }

    @Test
    public void shyShouldKeepItsColorWhileHidden()
    {
        machine.addSymbol("shy", 4, "purple");
        machine.placeSymbol(2, "purple");
        assertEquals("purple", machine.configuration()[1]);
        assertEquals(3, machine.distinctSymbols());
    }

    // ---------- Requisito 19: wild (propuesto) ----------

    @Test
    public void wildShouldCountAsAnySymbolForTheJackpot()
    {
        machine.addSymbol("wild", 4, "orange");
        machine.spin(new String[] {"blue", "orange", "blue"});
        assertTrue(machine.isJackpot());
        machine.spin(new String[] {"orange", "orange", "green"});
        assertTrue(machine.isJackpot());
    }

    @Test
    public void wildShouldNotMakeJackpotWhenTheOthersDiffer()
    {
        machine.addSymbol("wild", 4, "orange");
        machine.spin(new String[] {"red", "orange", "blue"});
        assertFalse(machine.isJackpot());
    }

    @Test
    public void wildShouldBeJackpotWhenEveryWheelShowsIt()
    {
        machine.addSymbol("wild", 4, "orange");
        machine.spin(new String[] {"orange", "orange", "orange"});
        assertTrue(machine.isJackpot());
    }

    @Test
    public void shouldNotStartWinningWithNormalElements()
    {
        for (int i = 0; i < 20; i++) {
            SlotMachine fresh = new SlotMachine(3);
            assertFalse(fresh.isJackpot());
        }
    }

    @Test
    public void contestShouldStillSolve()
    {
        for (int n = 3; n <= 8; n++) {
            SlotMachine fresh = new SlotMachine(n);
            SlotMachineContest.play(fresh, n);
            assertTrue(fresh.isJackpot());
        }
    }

    /**
     * Una rueda normal suelta con red, blue, green todos del tipo dado.
     */
    private Wheel wheelWith(String symbolType)
    {
        ArrayList<String> colors = new ArrayList<String>(Arrays.asList("red", "blue", "green"));
        ArrayList<String> types = new ArrayList<String>();
        for (int i = 0; i < colors.size(); i++) {
            types.add(symbolType);
        }
        return Wheel.create("normal", colors, types);
    }
}
