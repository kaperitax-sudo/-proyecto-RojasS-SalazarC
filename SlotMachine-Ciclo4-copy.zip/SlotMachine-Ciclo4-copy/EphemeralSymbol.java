/**
 * Simbolo efimero: en cada giro de su rueda se encoge
 * hasta quedar como un punto.
 * Se distingue por un punto blanco en el centro mientras es grande.
 */
public class EphemeralSymbol extends Symbol
{
    public static final int STEP = 4;               // cuanto se encoge por giro
    public static final int MIN_SIZE = 2;           // tamaño de "punto"
    private static final int DOT_LIMIT = 10;        // por debajo ya no cabe el punto blanco

    private int size;

    /**
     * Crea un simbolo efimero invisible, de tamaño completo.
     * @param color nombre de un color CSS
     */
    public EphemeralSymbol(String color)
    {
        super(color);
        size = SIZE;
    }

    @Override
    public String type()
    {
        return "ephemeral";
    }

    @Override
    public int size()
    {
        return size;
    }

    /**
     * Su rueda giro: se encoge, sin bajar del tamaño de un punto.
     */
    @Override
    public void turned()
    {
        size = Math.max(MIN_SIZE, size - STEP);
        arrange();
        if (isVisible) {
            draw();
        }
    }

    @Override
    protected void build()
    {
        parts.add(square(color));                    // el cuerpo
        parts.add(square("white"));                  // la marca del centro
    }

    @Override
    protected void arrange()
    {
        int offset = (SIZE - size) / 2;              // siempre centrado
        place(parts.get(0), offset, offset, size, size);
        int dot = Math.max(1, size / 3);
        int dotOffset = offset + (size - dot) / 2;
        place(parts.get(1), dotOffset, dotOffset, dot, dot);
    }

    @Override
    protected void draw()
    {
        parts.get(0).makeVisible();
        if (size >= DOT_LIMIT) {
            parts.get(1).makeVisible();              // encima del cuerpo
        }
        else {
            parts.get(1).makeInvisible();
        }
    }
}
