/**
 * Simbolo comodin (propuesto): para el premio cuenta como cualquier otro simbolo.
 * Si todas las ruedas muestran el mismo color o un comodin, hay premio.
 * Se dibuja como una cruz de su color sobre fondo blanco.
 */
public class WildSymbol extends Symbol
{
    private static final int MARGIN = 3;            // espacio entre el borde y la cruz
    private static final int BAR = 6;               // grueso de la cruz

    /**
     * Crea un simbolo comodin invisible.
     * @param color nombre de un color CSS
     */
    public WildSymbol(String color)
    {
        super(color);
    }

    @Override
    public String type()
    {
        return "wild";
    }

    @Override
    public boolean isWild()
    {
        return true;
    }

    @Override
    protected void build()
    {
        parts.add(square("white"));                  // el fondo
        parts.add(square(color));                    // barra horizontal
        parts.add(square(color));                    // barra vertical
    }

    @Override
    protected void arrange()
    {
        int length = SIZE - 2 * MARGIN;
        int middle = (SIZE - BAR) / 2;
        place(parts.get(0), 0, 0, SIZE, SIZE);
        place(parts.get(1), MARGIN, middle, length, BAR);
        place(parts.get(2), middle, MARGIN, BAR, length);
    }
}
