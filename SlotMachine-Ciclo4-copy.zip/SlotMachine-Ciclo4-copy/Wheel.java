import java.util.ArrayList;
import java.util.Random;

/**
 * Una rueda normal de la maquina. Tiene sus simbolos en orden
 * y muestra uno solo: el simbolo visible.
 * Es la base de los demas tipos de rueda (lefty, rebel, ...).
 * Para crear una rueda de cualquier tipo se usa
 * {@link #create(String, ArrayList, ArrayList)}.
 *
 * Un "giro" es spin(...) o rotate(...): avisa a todos sus simbolos
 * que la rueda giro y al simbolo que queda que fue seleccionado.
 * place(...) solo selecciona, no es un giro.
 */
public class Wheel
{
    public static final int WIDTH = 34;
    public static final int HEIGHT = 40;

    /** Tipos de rueda que conoce el simulador. */
    public static final String[] TYPES = {"normal", "lefty", "rebel"};

    protected ArrayList<Symbol> symbols;
    protected int current;                 // cual simbolo se ve
    protected int xPosition;
    protected int yPosition;
    protected boolean isVisible;
    private Rectangle window;              // el marco de la rueda
    private Rectangle mark;                // la marca del tipo, null si no tiene
    private boolean isLock;

    /**
     * Crea una rueda normal invisible con simbolos normales de los colores dados.
     * @param colors colores de los simbolos, en orden
     */
    public Wheel(ArrayList<String> colors)
    {
        this(colors, null);
    }

    /**
     * Crea una rueda normal invisible con los simbolos dados.
     * @param colors colores de los simbolos, en orden
     * @param types tipos de los simbolos, en el mismo orden; null si todos son normales
     */
    public Wheel(ArrayList<String> colors, ArrayList<String> types)
    {
        symbols = new ArrayList<Symbol>();
        for (int i = 0; i < colors.size(); i++) {
            String type = (types == null) ? "normal" : types.get(i);
            symbols.add(Symbol.create(type, colors.get(i)));
        }
        window = new Rectangle();
        window.changeSize(HEIGHT, WIDTH);
        window.changeColor("black");
        if (markColor() != null) {
            mark = new Rectangle();
            mark.changeColor(markColor());
        }
        current = 0;
        isVisible = false;
        isLock = false;
    }

    /**
     * Crea una rueda del tipo dado.
     * @param type tipo de rueda: normal, lefty o rebel
     * @param colors colores de los simbolos, en orden
     * @param types tipos de los simbolos, en el mismo orden
     * @return la rueda, o null si el tipo no existe
     */
    public static Wheel create(String type, ArrayList<String> colors, ArrayList<String> types)
    {
        String value = (type == null) ? "" : type.toLowerCase();
        switch (value) {
            case "normal": return new Wheel(colors, types);
            case "lefty":  return new LeftyWheel(colors, types);
            case "rebel":  return new RebelWheel(colors, types);
            default:       return null;
        }
    }

    /**
     * Indica si existe un tipo de rueda con ese nombre.
     * @param type nombre del tipo
     * @return true si el simulador lo conoce
     */
    public static boolean isType(String type)
    {
        if (type == null) {
            return false;
        }
        for (String known : TYPES) {
            if (known.equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Indica el tipo de la rueda.
     * @return nombre del tipo
     */
    public String type()
    {
        return "normal";
    }

    /**
     * Indica si la rueda se deja fijar.
     * @return true si se puede fijar
     */
    public boolean canBeLocked()
    {
        return true;
    }

    /**
     * Indica si la rueda se deja cambiar de puesto.
     * @return true si se puede intercambiar
     */
    public boolean canBeSwapped()
    {
        return true;
    }

    /**
     * Indica si la rueda se deja eliminar.
     * @return true si se puede eliminar
     */
    public boolean canBeDeleted()
    {
        return true;
    }

    /**
     * Adiciona un simbolo en la posicion dada.
     * @param index posicion en la lista
     * @param symbol el simbolo
     */
    public void addSymbol(int index, Symbol symbol)
    {
        symbols.add(index, symbol);
        refresh();
    }

    /**
     * Adiciona un simbolo normal en la posicion dada.
     * @param index posicion en la lista
     * @param color color del simbolo
     */
    public void addSymbol(int index, String color)
    {
        addSymbol(index, new Symbol(color));
    }

    /**
     * Elimina el simbolo de ese color.
     * @param color color del simbolo
     */
    public void delSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).is(color)) {
                symbols.get(i).makeInvisible();
                symbols.remove(i);
                break;                          // ya lo borro, sale
            }
        }
        refresh();
    }

    /**
     * Gira la rueda: deja visible un simbolo al azar.
     * @param random generador de la maquina
     */
    public void spin(Random random)
    {
        spin(random, null);
    }

    /**
     * Gira la rueda conociendo la rueda de su izquierda.
     * @param random generador de la maquina
     * @param left la rueda de la izquierda, o null si no hay
     */
    public void spin(Random random, Wheel left)
    {
        if (symbols.isEmpty()) {
            return;
        }
        turned();
        choose(random, left);
        selected();
    }

    /**
     * Rota la rueda un numero de pasos, en circulo, sin animacion.
     * Los pasos negativos rotan en sentido contrario.
     * @param steps numero de pasos
     */
    public void rotate(int steps)
    {
        rotate(steps, null, 0);
    }

    /**
     * Rota la rueda un numero de pasos, en circulo.
     * Si es visible y delay es mayor que cero se ve paso a paso.
     * @param steps numero de pasos, pueden ser negativos
     * @param left la rueda de la izquierda, o null si no hay
     * @param delay milisegundos por paso
     */
    public void rotate(int steps, Wheel left, int delay)
    {
        if (symbols.isEmpty()) {
            return;
        }
        turned();
        move(steps, left, delay);
        selected();
    }

    /**
     * Deja visible el simbolo de ese color. No es un giro.
     * @param color color del simbolo
     */
    public void place(String color)
    {
        int i = indexOf(color);
        if (i >= 0) {
            current = i;
            selected();
        }
    }

    /**
     * Indica el color del simbolo visible.
     * @return el color, o cadena vacia si no hay simbolos
     */
    public String symbol()
    {
        if (symbols.isEmpty()) {
            return "";
        }
        return currentSymbol().color();
    }

    /**
     * Indica si el simbolo visible es comodin.
     * @return true si es comodin
     */
    public boolean isWild()
    {
        return !symbols.isEmpty() && currentSymbol().isWild();
    }

    /**
     * Da el simbolo de ese color.
     * @param color color del simbolo
     * @return el simbolo, o null si la rueda no lo tiene
     */
    public Symbol getSymbol(String color)
    {
        int i = indexOf(color);
        return (i < 0) ? null : symbols.get(i);
    }

    /**
     * Ubica la rueda en el canvas.
     * @param x coordenada horizontal
     * @param y coordenada vertical
     */
    public void moveTo(int x, int y)
    {
        xPosition = x;
        yPosition = y;
        window.moveTo(x, y);
        if (mark != null) {
            int[] b = markBounds();
            mark.changeSize(b[3], b[2]);
            mark.moveTo(x + b[0], y + b[1]);
        }
        refresh();
    }

    /**
     * Cambia el color del marco.
     * @param color nombre de un color CSS
     */
    public void changeColor(String color)
    {
        window.changeColor(color);
    }

    /**
     * Hace visible la rueda.
     */
    public void makeVisible()
    {
        isVisible = true;
        window.makeVisible();
        if (mark != null) {
            mark.makeVisible();
        }
        refresh();
    }

    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible()
    {
        hideAll();
        window.makeInvisible();
        if (mark != null) {
            mark.makeInvisible();
        }
        isVisible = false;
    }

    /**
     * Indica si la rueda esta fija.
     * @return true si esta fija
     */
    public boolean getLock()
    {
        return isLock;
    }

    /**
     * Fija o suelta la rueda. Si no se deja fijar, sigue suelta.
     * @param lk true para fijarla
     */
    public void setLock(boolean lk)
    {
        isLock = lk && canBeLocked();
    }

    /**
     * Escoge el simbolo que queda despues de un giro al azar.
     * La normal escoge al azar.
     * @param random generador de la maquina
     * @param left la rueda de la izquierda, o null si no hay
     */
    protected void choose(Random random, Wheel left)
    {
        current = random.nextInt(symbols.size());   // 0 hasta size-1
    }

    /**
     * Mueve la rueda los pasos pedidos. La normal avanza en circulo.
     * @param steps numero de pasos, pueden ser negativos
     * @param left la rueda de la izquierda, o null si no hay
     * @param delay milisegundos por paso, 0 para no animar
     */
    protected void move(int steps, Wheel left, int delay)
    {
        if (isVisible && delay > 0) {
            int one = (steps < 0) ? -1 : 1;
            for (int i = 0; i < Math.abs(steps); i++) {
                current = circular(current + one);
                refresh();
                Canvas.getCanvas().wait(delay);
            }
        }
        else {
            current = circular(current + steps);
        }
    }

    /**
     * Copia el simbolo visible de otra rueda, si lo tiene.
     * @param other la rueda a copiar
     */
    protected void copy(Wheel other)
    {
        int i = indexOf(other.symbol());
        if (i >= 0) {
            current = i;
        }
    }

    /**
     * Color de la marca que distingue el tipo de rueda.
     * @return el color, o null si no lleva marca
     */
    protected String markColor()
    {
        return null;
    }

    /**
     * Donde va la marca, relativa a la esquina de la rueda.
     * @return {dx, dy, ancho, alto}
     */
    protected int[] markBounds()
    {
        return new int[] {0, 0, 0, 0};
    }

    /**
     * Avisa a todos los simbolos que la rueda giro.
     */
    private void turned()
    {
        for (Symbol symbol : symbols) {
            symbol.turned();
        }
    }

    /**
     * Avisa al simbolo visible que fue seleccionado y lo muestra.
     */
    private void selected()
    {
        fixCurrent();
        currentSymbol().selected();
        refresh();
    }

    private Symbol currentSymbol()
    {
        fixCurrent();
        return symbols.get(current);
    }

    private int indexOf(String color)
    {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).is(color)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Lleva una posicion al rango de la rueda, dando vueltas.
     */
    private int circular(int position)
    {
        int size = symbols.size();
        return ((position % size) + size) % size;
    }

    /**
     * Esconde todo y muestra el simbolo que toca.
     */
    private void refresh()
    {
        hideAll();
        if (symbols.isEmpty()) {
            return;
        }
        fixCurrent();
        showCurrent();
    }

    /**
     * Baja current si quedo fuera de rango al borrar simbolos.
     */
    private void fixCurrent()
    {
        if (current >= symbols.size()) {
            current = symbols.size() - 1;
        }
        if (current < 0) {
            current = 0;
        }
    }

    /**
     * Ubica y muestra el simbolo visible, centrado en la rueda.
     */
    private void showCurrent()
    {
        int x = xPosition + (WIDTH - Symbol.SIZE) / 2;
        int y = yPosition + (HEIGHT - Symbol.SIZE) / 2;
        Symbol symbol = symbols.get(current);
        symbol.moveTo(x, y);
        if (isVisible) {
            symbol.makeVisible();
        }
    }

    /**
     * Esconde todos los simbolos.
     */
    private void hideAll()
    {
        for (Symbol symbol : symbols) {
            symbol.makeInvisible();
        }
    }
}
