import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Casos de prueba compartidos del ciclo 4.
 * Rs: Rojas Solano. S: Salazar.
 * Todas las pruebas corren con la maquina invisible.
 */
public class SlotMachineCC4Test
{
    private SlotMachine machine;

    /**
     * Arma una maquina de tres simbolos y tres ruedas,
     * cada rueda en un simbolo distinto.
     */
    @Before
    public void setUp()
    {
        machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.placeSymbol(3, "green");
    }

    /**
     * Requisito 17. Una rueda lefty copia a la de su izquierda al girar.
     */
    @Test
    public void accordingRsSShouldCopyTheLeftWheelWithALeftyWheel()
    {
        machine.addWheel("lefty", 4);
        machine.spin(4);
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[3]);
    }

    /**
     * Requisito 17. Una rueda rebel no se deja fijar, ni intercambiar, ni eliminar.
     */
    @Test
    public void accordingRsSShouldNotLockSwapOrDeleteARebelWheel()
    {
        machine.addWheel("rebel", 4);
        machine.lock(4);
        assertFalse(machine.ok());
        machine.swap(1, 4);
        assertFalse(machine.ok());
        machine.delWheel(4);
        assertFalse(machine.ok());
        assertEquals(4, machine.configuration().length);
    }

    /**
     * Requisito 18. Los simbolos de cualquier tipo se adicionan en todas las ruedas.
     */
    @Test
    public void accordingRsSShouldAddEphemeralAndShySymbols()
    {
        machine.addSymbol("ephemeral", 4, "yellow");
        assertTrue(machine.ok());
        machine.addSymbol("shy", 5, "purple");
        assertTrue(machine.ok());
        machine.spin(new String[] {"yellow", "yellow", "yellow"});
        assertTrue(machine.isJackpot());
    }
}
