import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda zurda: si hay una rueda a su izquierda, al girar copia su estado
 * (queda mostrando el mismo simbolo). Si no hay, gira como una normal.
 * Se distingue por una barra azul claro (skyblue) encima.
 */
public class LeftyWheel extends Wheel
{
    /**
     * Crea una rueda zurda invisible con los simbolos dados.
     * @param colors colores de los simbolos, en orden
     * @param types tipos de los simbolos, en el mismo orden; null si todos son normales
     */
    public LeftyWheel(ArrayList<String> colors, ArrayList<String> types)
    {
        super(colors, types);
    }

    @Override
    public String type()
    {
        return "lefty";
    }

    @Override
    protected void choose(Random random, Wheel left)
    {
        if (left == null) {
            super.choose(random, left);
        }
        else {
            copy(left);
        }
    }

    @Override
    protected void move(int steps, Wheel left, int delay)
    {
        if (left == null) {
            super.move(steps, left, delay);
        }
        else {
            copy(left);
        }
    }

    @Override
    protected String markColor()
    {
        return "skyblue";
    }

    @Override
    protected int[] markBounds()
    {
        return new int[] {0, -8, WIDTH, 5};          // barra horizontal encima
    }
}
