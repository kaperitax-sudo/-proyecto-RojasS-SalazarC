import java.util.ArrayList;

/**
 * Rueda rebelde: no se deja fijar, ni intercambiar, ni eliminar.
 * Gira como una normal.
 * Se distingue por una barra roja debajo.
 */
public class RebelWheel extends Wheel
{
    /**
     * Crea una rueda rebelde invisible con los simbolos dados.
     * @param colors colores de los simbolos, en orden
     * @param types tipos de los simbolos, en el mismo orden; null si todos son normales
     */
    public RebelWheel(ArrayList<String> colors, ArrayList<String> types)
    {
        super(colors, types);
    }

    @Override
    public String type()
    {
        return "rebel";
    }

    @Override
    public boolean canBeLocked()
    {
        return false;
    }

    @Override
    public boolean canBeSwapped()
    {
        return false;
    }

    @Override
    public boolean canBeDeleted()
    {
        return false;
    }

    @Override
    protected String markColor()
    {
        return "red";
    }

    @Override
    protected int[] markBounds()
    {
        return new int[] {0, HEIGHT + 3, WIDTH, 5};  // barra horizontal debajo
    }
}
