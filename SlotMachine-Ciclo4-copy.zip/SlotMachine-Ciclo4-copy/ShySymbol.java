/**
 * Simbolo timido: cada vez que su rueda lo selecciona
 * alterna entre visible e invisible.
 * Visible se dibuja con una franja negra arriba (un "parpado");
 * escondido solo deja ver un puntico blanco en el centro.
 * Aunque este escondido, sigue siendo el simbolo de la rueda.
 */
public class ShySymbol extends Symbol
{
    private static final int LID = 5;               // alto de la franja
    private static final int GHOST = 4;             // lado del puntico

    private boolean hidden;

    /**
     * Crea un simbolo timido invisible, que empieza dejandose ver.
     * @param color nombre de un color CSS
     */
    public ShySymbol(String color)
    {
        super(color);
        hidden = false;
    }

    @Override
    public String type()
    {
        return "shy";
    }

    @Override
    public boolean isShown()
    {
        return !hidden;
    }

    /**
     * Lo seleccionaron: si se veia se esconde y si estaba escondido se deja ver.
     */
    @Override
    public void selected()
    {
        hidden = !hidden;
        if (isVisible) {
            draw();
        }
    }

    @Override
    protected void build()
    {
        parts.add(square(color));                    // el cuerpo
        parts.add(square("black"));                  // el parpado
        parts.add(square("white"));              // el puntico cuando se esconde
    }

    @Override
    protected void arrange()
    {
        place(parts.get(0), 0, 0, SIZE, SIZE);
        place(parts.get(1), 0, 0, SIZE, LID);
        int ghost = (SIZE - GHOST) / 2;
        place(parts.get(2), ghost, ghost, GHOST, GHOST);
    }

    @Override
    protected void draw()
    {
        if (hidden) {
            parts.get(0).makeInvisible();
            parts.get(1).makeInvisible();
            parts.get(2).makeVisible();
        }
        else {
            parts.get(2).makeInvisible();
            parts.get(0).makeVisible();
            parts.get(1).makeVisible();
        }
    }
}
