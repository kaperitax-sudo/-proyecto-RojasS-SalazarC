import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * Simulador de una maquina tragamonedas.
 * La maquina tiene ruedas y todas las ruedas tienen los mismos simbolos.
 * Cada simbolo se identifica por su color y todos son diferentes.
 *
 * Ciclo 4: hay diferentes tipos de ruedas (normal, lefty, rebel)
 * y de simbolos (normal, ephemeral, shy, wild).
 */
public class SlotMachine
{
    public static final int MAX_WHEELS = 50;
    public static final int MAX_SYMBOLS = 50;

    private static final int BODY_X = 10;          // esquina del cuerpo
    private static final int BODY_Y = 60;
    private static final int BODY_WIDTH = 280;     // el canvas mide 300
    private static final int BODY_HEIGHT = 110;
    private static final int GAP = 8;              // espacio entre ruedas
    private static final int STEP_DELAY = 120;     // milisegundos por paso

    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;             // los colores, en orden
    private ArrayList<String> symbolTypes;         // el tipo de cada color, en el mismo orden
    private Rectangle body;                        // el cuerpo de la maquina
    private Random random;
    private boolean isVisible;
    private boolean ok;                            // si se pudo la ultima operacion

    /**
     * Crea una maquina vacia e invisible.
     */
    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        symbolTypes = new ArrayList<String>();
        random = new Random();
        body = new Rectangle();
        body.changeSize(BODY_HEIGHT, BODY_WIDTH);
        body.moveTo(BODY_X, BODY_Y);
        body.changeColor("dimgray");
        isVisible = false;
        ok = true;
    }

    /**
     * Crea una maquina de n ruedas y n simbolos, invisible
     * y con cada rueda en un simbolo al azar.
     * @param n numero de ruedas y de simbolos, entre 3 y 50
     */
    public SlotMachine(int n)
    {
        this();                                    // arranca como la maquina vacia
        if (n < 3 || n > MAX_WHEELS) {
            ok = false;                            // n no sirve, queda vacia
            return;
        }

        String[] colors = Colors.palette(n);       // n colores distintos
        for (int i = 0; i < n; i++) {
            addSymbol(i + 1, colors[i]);           // posiciones desde 1
        }

        for (int i = 0; i < n; i++) {
            addWheel(i + 1);
        }

        spin();                                    // cada rueda en un simbolo al azar
        while (isJackpot()) {
            spin();                                // no puede empezar ganando
        }

        ok = true;
    }

    /**
     * Adiciona una rueda normal en la posicion dada.
     * @param pos posicion de la rueda, empezando en 1
     */
    public void addWheel(int pos)
    {
        addWheel("normal", pos);
    }

    /**
     * Adiciona una rueda del tipo dado en la posicion dada.
     * @param type tipo de rueda: normal, lefty o rebel
     * @param pos posicion de la rueda, empezando en 1
     */
    public void addWheel(String type, int pos)
    {
        if (wheels.size() >= MAX_WHEELS) {
            error("No puede tener mas de " + MAX_WHEELS + " ruedas.");
            return;
        }
        if (!Wheel.isType(type)) {
            error("No existe el tipo de rueda " + type + ".");
            return;
        }
        Wheel wheel = Wheel.create(type, symbols, symbolTypes);   // nace con los simbolos actuales
        wheels.add(index(pos, wheels.size() + 1), wheel);
        if (isVisible) {
            wheel.makeVisible();
        }
        layout();
        ok = true;
    }

    /**
     * Elimina la rueda de la posicion dada.
     * @param pos posicion de la rueda, empezando en 1
     */
    public void delWheel(int pos)
    {
        if (wheels.isEmpty()) {
            error("La maquina no tiene ruedas.");
            return;
        }
        int i = index(pos, wheels.size());
        if (!wheels.get(i).canBeDeleted()) {
            error("La rueda " + (i + 1) + " no se deja eliminar.");
            return;
        }
        Wheel wheel = wheels.remove(i);
        wheel.makeInvisible();
        layout();
        ok = true;
    }

    /**
     * Intercambia dos ruedas de posicion.
     * @param wheel1 posicion de la primera rueda, empezando en 1
     * @param wheel2 posicion de la segunda rueda, empezando en 1
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheels.size() < 2) {
            error("La maquina necesita al menos dos ruedas.");
            return;
        }

        int first = index(wheel1, wheels.size());
        int second = index(wheel2, wheels.size());

        if (first == second) {
            error("Las dos ruedas deben ser diferentes.");
            return;
        }
        if (!wheels.get(first).canBeSwapped() || !wheels.get(second).canBeSwapped()) {
            error("Alguna de las ruedas no se deja intercambiar.");
            return;
        }

        Wheel temp = wheels.get(first);
        wheels.set(first, wheels.get(second));
        wheels.set(second, temp);
        layout();
        ok = true;
    }

    /**
     * Adiciona un simbolo normal en la posicion dada.
     * @param pos posicion del simbolo, empezando en 1
     * @param color nombre de un color CSS, diferente a los actuales
     */
    public void addSymbol(int pos, String color)
    {
        addSymbol("normal", pos, color);
    }

    /**
     * Adiciona un simbolo del tipo dado en la posicion dada, en todas las ruedas.
     * @param type tipo de simbolo: normal, ephemeral, shy o wild
     * @param pos posicion del simbolo, empezando en 1
     * @param color nombre de un color CSS, diferente a los actuales
     */
    public void addSymbol(String type, int pos, String color)
    {
        if (!Symbol.isType(type)) {
            error("No existe el tipo de simbolo " + type + ".");
            return;
        }
        if (symbols.size() >= MAX_SYMBOLS) {
            error("No puede tener mas de " + MAX_SYMBOLS + " simbolos.");
            return;
        }
        if (!Colors.isValid(color)) {
            error("El color " + color + " no existe.");
            return;
        }
        String value = color.toLowerCase();
        if (symbols.contains(value)) {
            error("Los simbolos deben ser de colores diferentes.");
            return;
        }
        insert(index(pos, symbols.size() + 1), type.toLowerCase(), value);
        ok = true;
    }

    /**
     * Elimina el simbolo de ese color.
     * @param symbol nombre del color
     */
    public void delSymbol(String symbol)
    {
        String value = "";
        if (symbol != null) {
            value = symbol.toLowerCase();
        }
        int i = symbols.indexOf(value);
        if (i < 0) {
            error("La maquina no tiene el simbolo " + symbol + ".");
            return;
        }
        symbols.remove(i);
        symbolTypes.remove(i);
        for (Wheel wheel : wheels) {
            wheel.delSymbol(value);
        }
        refresh();
        ok = true;
    }

    /**
     * Deja visible un simbolo en una rueda.
     * @param wheel posicion de la rueda, empezando en 1
     * @param symbol nombre del color
     */
    public void placeSymbol(int wheel, String symbol)
    {
        if (wheels.isEmpty()) {
            error("La maquina no tiene ruedas.");
            return;
        }
        String value = "";
        if (symbol != null) {
            value = symbol.toLowerCase();
        }
        if (!symbols.contains(value)) {
            error("La maquina no tiene el simbolo " + symbol + ".");
            return;
        }
        wheels.get(index(wheel, wheels.size())).place(value);
        refresh();
        ok = true;
    }

    /**
     * Gira una rueda, si no esta fija.
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void spin(int wheel)
    {
        if (!canSpin()) {
            return;
        }
        int i = index(wheel, wheels.size());
        Wheel target = wheels.get(i);
        if (target.getLock()) {
            error("La rueda " + wheel + " esta fija.");
            return;
        }
        target.spin(random, left(i));
        refresh();
        ok = true;
    }

    /**
     * Gira todas las ruedas que no esten fijas.
     * Las ruedas fijas conservan su simbolo visible.
     */
    public void spin()
    {
        if (!canSpin()) {
            return;
        }
        for (int i = 0; i < wheels.size(); i++) {  // de izquierda a derecha
            Wheel wheel = wheels.get(i);
            if (!wheel.getLock()) {
                wheel.spin(random, left(i));
            }
        }
        refresh();
        ok = true;
    }

    /**
     * Rota una rueda un numero de pasos, si no esta fija.
     * Si la maquina es visible el movimiento se ve paso a paso.
     * @param wheel posicion de la rueda, empezando en 1
     * @param steps numero de pasos, puede ser negativo
     */
    public void spin(int wheel, int steps)
    {
        if (!canSpin()) {
            return;
        }
        int i = index(wheel, wheels.size());
        Wheel target = wheels.get(i);
        if (target.getLock()) {
            error("La rueda " + wheel + " esta fija.");
            return;
        }
        target.rotate(steps, left(i), isVisible ? STEP_DELAY : 0);
        refresh();
        ok = true;
    }

    /**
     * Deja la maquina en la configuracion dada.
     * O se aplica completa, o no se aplica nada.
     * @param setSymbols colores deseados, uno por rueda, de izquierda a derecha
     */
    public void spin(String[] setSymbols)
    {
        if (!canSpin()) {
            return;
        }
        if (setSymbols == null || setSymbols.length != wheels.size()) {
            error("La configuracion debe tener " + wheels.size() + " simbolos.");
            return;
        }
        String[] values = new String[setSymbols.length];
        for (int i = 0; i < setSymbols.length; i++) {
            if (setSymbols[i] == null) {
                error("La configuracion tiene un simbolo vacio.");
                return;
            }
            values[i] = setSymbols[i].toLowerCase();
            if (!symbols.contains(values[i])) {
                error("La maquina no tiene el simbolo " + setSymbols[i] + ".");
                return;
            }
            if (wheels.get(i).getLock() && !wheels.get(i).symbol().equals(values[i])) {
                error("La rueda " + (i + 1) + " esta fija.");
                return;
            }
        }
        for (int i = 0; i < values.length; i++) {
            wheels.get(i).place(values[i]);
        }
        refresh();
        ok = true;
    }

    /**
     * Consulta los simbolos de la maquina, en el orden de la rueda.
     * @return los colores de los simbolos
     */
    public String[] symbols()
    {
        ok = true;
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i);
        }
        return result;
    }

    /**
     * Consulta cuantos colores diferentes hay en la configuracion.
     * @return numero de simbolos distintos visibles
     */
    public int distinctSymbols()
    {
        ArrayList<String> found = new ArrayList<String>();
        for (Wheel wheel : wheels) {
            String color = wheel.symbol();
            if (!color.equals("") && !found.contains(color)) {
                found.add(color);                  // solo si no estaba
            }
        }
        ok = true;
        return found.size();
    }

    /**
     * Consulta los colores visibles, de izquierda a derecha.
     * @return la configuracion actual
     */
    public String[] configuration()
    {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = wheels.get(i).symbol();
        }
        ok = true;
        return result;
    }

    /**
     * Indica si la configuracion es la ganadora.
     * @return true si todas las ruedas muestran lo mismo
     */
    public boolean isJackpot()
    {
        ok = true;
        return jackpot();
    }

    /**
     * Hace visible el simulador.
     */
    public void makeVisible()
    {
        isVisible = true;
        body.makeVisible();
        for (Wheel wheel : wheels) {
            wheel.makeVisible();
        }
        refresh();
        ok = true;
    }

    /**
     * Hace invisible el simulador. La maquina sigue funcionando.
     */
    public void makeInvisible()
    {
        for (Wheel wheel : wheels) {
            wheel.makeInvisible();
        }
        body.makeInvisible();
        isVisible = false;
        ok = true;
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        makeInvisible();
        System.exit(0);
    }

    /**
     * Indica si se logro realizar la ultima operacion.
     * @return true si se pudo
     */
    public boolean ok()
    {
        return ok;
    }

    /**
     * Fija una rueda para que no gire.
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void lock(int wheel)
    {
        setLock(wheel, true);
    }

    /**
     * Suelta una rueda para que vuelva a girar.
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void unlock(int wheel)
    {
        setLock(wheel, false);
    }

    /**
     * Mete el simbolo en la maquina y en todas las ruedas.
     * Cada rueda recibe su propio objeto simbolo.
     */
    private void insert(int position, String type, String color)
    {
        symbols.add(position, color);
        symbolTypes.add(position, type);
        for (Wheel wheel : wheels) {
            wheel.addSymbol(position, Symbol.create(type, color));
        }
        refresh();
    }

    /**
     * Da la rueda a la izquierda del indice dado.
     * @return la rueda, o null si es la primera
     */
    private Wheel left(int i)
    {
        return (i > 0) ? wheels.get(i - 1) : null;
    }

    /**
     * Revisa si se puede girar y avisa si no.
     */
    private boolean canSpin()
    {
        if (wheels.isEmpty()) {
            error("La maquina no tiene ruedas.");
            return false;
        }
        if (symbols.isEmpty()) {
            error("La maquina no tiene simbolos.");
            return false;
        }
        return true;
    }

    /**
     * Calcula si todas las ruedas muestran el mismo simbolo.
     * Los simbolos comodin (wild) valen por cualquiera.
     */
    private boolean jackpot()
    {
        if (wheels.isEmpty() || symbols.isEmpty()) {
            return false;
        }
        String first = null;
        for (Wheel wheel : wheels) {
            if (wheel.isWild()) {
                continue;                          // el comodin sirve con todos
            }
            if (first == null) {
                first = wheel.symbol();
            }
            else if (!first.equals(wheel.symbol())) {
                return false;                      // uno distinto y ya no gana
            }
        }
        return true;
    }

    /**
     * Reparte las ruedas centradas dentro del cuerpo.
     */
    private void layout()
    {
        int used = wheels.size() * Wheel.WIDTH + (wheels.size() - 1) * GAP;
        int x = BODY_X + (BODY_WIDTH - used) / 2;
        int y = BODY_Y + (BODY_HEIGHT - Wheel.HEIGHT) / 2;
        for (Wheel wheel : wheels) {
            wheel.moveTo(x, y);
            x = x + Wheel.WIDTH + GAP;             // la siguiente mas a la derecha
        }
        refresh();
    }

    /**
     * La maquina luce diferente si llego a un estado ganador.
     */
    private void refresh()
    {
        if (jackpot()) {
            paint("gold", "gold");
        }
        else {
            paint("dimgray", "black");
        }
    }

    /**
     * Pinta el cuerpo y los marcos de las ruedas.
     */
    private void paint(String bodyColor, String wheelColor)
    {
        body.changeColor(bodyColor);
        for (Wheel wheel : wheels) {
            wheel.changeColor(wheelColor);
            if (isVisible) {
                wheel.makeVisible();               // la redibuja encima del cuerpo
            }
        }
    }

    /**
     * Pasa una posicion del usuario (desde 1) a un indice de lista (desde 0).
     * Si es menor que 1 usa 1, si es mayor que max usa max.
     */
    private int index(int pos, int max)
    {
        if (pos < 1) {
            pos = 1;
        }
        if (pos > max) {
            pos = max;
        }
        return pos - 1;
    }

    /**
     * Avisa al usuario, solo si el simulador esta visible.
     */
    private void error(String message)
    {
        ok = false;
        if (isVisible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Fija o suelta la rueda de la posicion dada.
     * Una rueda que no se deja fijar (rebel) produce error.
     */
    private void setLock(int wheel, boolean value)
    {
        if (wheels.isEmpty()) {
            error("La maquina no tiene ruedas.");
            return;
        }
        Wheel target = wheels.get(index(wheel, wheels.size()));
        if (value && !target.canBeLocked()) {
            error("La rueda " + wheel + " no se deja fijar.");
            return;
        }
        target.setLock(value);
        ok = true;
    }
}
