import static org.junit.Assert.*;
import javax.swing.JOptionPane;
import org.junit.Test;

/**
 * Pruebas de aceptacion del ciclo 4, para la presentacion.
 * Corren con la maquina visible y al final le preguntan al usuario
 * si el comportamiento observado es el esperado.
 */
public class SlotMachineATest
{
    private static final int PAUSE = 900;

    /**
     * Ruedas: una normal, una lefty (barra azul claro arriba) y una rebel (barra roja abajo).
     * Se gira la lefty y copia a la normal; la rebel no se deja eliminar ni fijar.
     */
    @Test
    public void shouldShowTheThreeWheelTypes()
    {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.addSymbol(4, "gold");
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.placeSymbol(1, "green");
        machine.placeSymbol(2, "red");
        machine.placeSymbol(3, "blue");
        machine.makeVisible();
        pause();
        machine.spin(2, 1);                            // la lefty copia: queda green
        pause();
        machine.spin(1, 2);                            // la normal avanza 2: gold
        pause();
        machine.spin();                                // la lefty sigue a la normal
        pause();
        machine.delWheel(3);                           // la rebel no se deja: aviso
        machine.lock(3);                               // tampoco se deja fijar: aviso
        boolean accepted = ask("La rueda de barra azul copio a su izquierda y la de barra roja no se dejo "
                               + "eliminar ni fijar?");
        machine.makeInvisible();
        assertTrue(accepted);
    }

    /**
     * Simbolos: ephemeral se encoge en cada giro, shy aparece y desaparece
     * cada vez que la rueda lo selecciona, y wild (cruz) da premio con cualquiera.
     */
    @Test
    public void shouldShowTheSymbolTypes()
    {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("ephemeral", 1, "red");
        machine.addSymbol("shy", 2, "blue");
        machine.addSymbol("wild", 3, "orange");
        machine.addSymbol("normal", 4, "green");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.spin(new String[] {"red", "green", "green"});
        machine.makeVisible();
        pause();
        for (int i = 0; i < 4; i++) {                  // cuatro vueltas completas
            machine.spin(1, 4);                        // el rojo se encoge cada vez
            pause();
        }
        machine.placeSymbol(2, "blue");                // el azul se esconde
        pause();
        machine.placeSymbol(2, "blue");                // y vuelve a aparecer
        pause();
        machine.spin(new String[] {"orange", "green", "green"});  // el comodin da premio
        pause();
        boolean accepted = ask("El rojo se encogio, el azul se escondio y volvio, "
                               + "y la cruz naranja dio premio (maquina dorada)?");
        machine.makeInvisible();
        assertTrue(accepted);
    }

    private void pause()
    {
        Canvas.getCanvas().wait(PAUSE);
    }

    private boolean ask(String question)
    {
        int answer = JOptionPane.showConfirmDialog(null, question, "Prueba de aceptacion",
                                                   JOptionPane.YES_NO_OPTION);
        return answer == JOptionPane.YES_OPTION;
    }
}
